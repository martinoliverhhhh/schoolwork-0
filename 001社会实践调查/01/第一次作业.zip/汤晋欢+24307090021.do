/*******************************************************************************
* 课程名称：社会研究实践（定量方向）/ 社会实践调查
* 提交项目：作业一（变量构造与规范数据操作）
* 学生姓名：汤晋欢
* 学生学号：24307090021
* 赛道与选题：赛道一（教育、收入与代际地位获得）
* 复刻文献：唐俊超．2015．《输在起跑线——再议中国社会的教育不平等（1978—2008）》．《社会学研究》第3期．
* 数据来源：中国综合社会调查（CGSS 2023）官方公开发布数据集（N=11,326, K=437）
* 运行环境：Stata/MP 18.0 (macOS)
* 依赖宏包：iscogen (v1.0.6, Ben Jann)
* 生成文件：汤晋欢+24307090021.log, CGSS2023_cleaned_tangjinhuan.dta
*******************************************************************************/

version 18
clear all
set more off
capture log close

// 开启真实不可编辑日志（纯文本格式，与代码严格对应）
log using "汤晋欢+24307090021.log", text replace

// 设定固定随机数种子，确保所有过程100%可复现
set seed 20261105

di as text "================================================================================"
di as text "复旦大学《社会实践调查》作业一：数据清洗与变量构造规范脚本"
di as text "学生：汤晋欢 (24307090021)   执行时间：" c(current_date) " " c(current_time)
di as text "================================================================================"

// =============================================================================
// 第一部分：数据读取与样本结构探查 (Data Ingestion)
// =============================================================================
di as text _newline ">>> 第一部分：读取原始 CGSS 2023 官方数据"
use "CGSS2023.dta", clear

count
di as text "原始 CGSS 2023 全样本总数 N = " r(N) "，总变量数 K = " c(k)

// 探查调查模式分布
tabulate dsource, missing

// =============================================================================
// 第二部分：样本筛选——严格限定入户面访调查样本 (Sample Filtering)
// =============================================================================
di as text _newline ">>> 第二部分：样本筛选——限定入户面访调查样本 (dsource == 1)"
/* 样本筛选学术依据与制度说明：
   CGSS 2023 采用双轨抽样调查模式：
   1. 入户面访调查样本（dsource == 1）：N = 5,583（占比 49.29%）；
   2. 电话调查（CATI）样本（dsource == 2）：N = 5,743（占比 50.71%）。
   由于电话调查受访谈时间限制大幅精简了问卷题量，本研究核心理论变量：
   - 14岁时父亲职业代码 (isco08f)
   - 城乡社区属性 (isurban)
   - 个人劳动收入 (a8b)
   - 社会资本网络位置发生器 (c9a-c9j)
   在电话调查中均未予施测，全部统一编码为系统特殊保留值 -5（“电话调查未调查”）。
   若盲目使用全样本，将导致核心代际变量出现超 50% 的非随机系统性缺失，破坏样本代表性。
   因此，本研究严格遵照课程指引与规范，限定于入户面访调查样本 (N = 5,583)，
   并在后续分析与描述统计中匹配使用入户设计权重 (weight1)。*/

keep if dsource == 1
count
di as text "筛选后入户面访基准分析样本量 N = " r(N)
assert r(N) == 5583

// =============================================================================
// 第三部分：缺失值与特殊异常值标准化清洗 (Missing Value Cleaning)
// =============================================================================
di as text _newline ">>> 第三部分：缺失值统一标准化处理"

// 3.1 统一问卷标准负值缺失编码 (-1 至 -5)
/* CGSS 标准缺失代码含义：
   -1 = 不适用 (Not applicable)
   -2 = 不知道 (Don't know)
   -3 = 拒绝回答 (Refuse to answer)
   -4 = 入户面访未调查
   -5 = 电话调查未调查
   所有负值编码在统计分析前均应统一转换为系统缺失值 (.)。*/

// 针对研究所涉及的所有核心数值型变量进行标准负值缺失清洗
local survey_vars a2 a3a a4 a7a a8a a18 a43a a43d a89b a90b isurban isco08f isco08a59d c9a c9b c9c c9d c9e c9f c9g c9h c9i c9j
foreach var of local survey_vars {
    recode `var' (-5/-1 = .)
}

// 3.2 连续型货币变量（收入 a8a）的百万位特殊缺失代码与负值亏损处理
/* 关键坑点排查说明：
   在 CGSS 2023 的连续收入变量 (a8a) 中，存在四类高位特殊调查缺失代码：
   9999996 = 收入高于百万位数（无法精确填写）
   9999997 = 不适用
   9999998 = 不知道
   9999999 = 拒绝回答
   此外，部分经营性自雇样本存在亏损申报（负数）。
   若不先行识别并清除，取对数后 9999999 将被算作 16.12 的虚假超高收入，严重污染数据分布。*/

di as text "清洗前 a8a 极端值与特殊代码频数检查："
count if inlist(a8a, 9999996, 9999997, 9999998, 9999999)
di as text "入户样本中 a8a 百万位特殊缺失代码频数 = " r(N)

replace a8a = . if inlist(a8a, 9999996, 9999997, 9999998, 9999999)
replace a8a = . if a8a < 0

count if a8a != .
di as text "清洗后个人年总收入有效样本量 N = " r(N)
assert r(N) == 5359

// =============================================================================
// 第四部分：核心分析变量构造 (Core Variable Construction)
// =============================================================================
di as text _newline ">>> 第四部分：核心因变量、自变量与控制变量构造"

// -----------------------------------------------------------------------------
// 4.1 因变量：教育获得与 Mare 顺序升学转换指标 (基于 a7a)
// -----------------------------------------------------------------------------
/* 剔除 a7a 中的代码 14 (其他，仅 1 例) */
replace a7a = . if a7a == 14

// 连续受教育年限 (edu_years)
gen edu_years = .
replace edu_years = 0  if a7a == 1                  // 没有受过任何教育
replace edu_years = 2  if a7a == 2                  // 私塾/扫盲班
replace edu_years = 6  if a7a == 3                  // 小学
replace edu_years = 9  if a7a == 4                  // 初中
replace edu_years = 12 if inlist(a7a, 5, 6, 7, 8)   // 职业高中/普通高中/中专/技校
replace edu_years = 15 if inlist(a7a, 9, 10)        // 成人大专/普通大专
replace edu_years = 16 if inlist(a7a, 11, 12)       // 成人本科/普通本科
replace edu_years = 19 if a7a == 13                 // 研究生及以上
label var edu_years "受教育年限(年)"

// 有序教育层次 (edu_ord)
recode a7a (1/3 = 1 "小学及以下") (4 = 2 "初中") (5/8 = 3 "高中/中专/技校") (9/13 = 4 "大专及以上"), gen(edu_ord)
label var edu_ord "教育层次(四分类)"

// Mare 顺序二元升学转换指标 (Mare Transition Model)
// 转换 1: 小学升初中 (完成初中，基准合格群体为小学及以上 a7a >= 3)
gen trans1_jh = .
replace trans1_jh = 1 if a7a >= 4 & a7a != .
replace trans1_jh = 0 if a7a == 3
label var trans1_jh "升学转换1:完成初中(小学及以上样本)"

// 转换 2: 初中升高中 (完成高中，条件合格群体为完成初中 a7a >= 4)
gen trans2_sh = .
replace trans2_sh = 1 if a7a >= 5 & a7a != .
replace trans2_sh = 0 if a7a == 4
label var trans2_sh "升学转换2:完成高中(初中及以上样本)"

// 转换 3: 高中升大学 (完成大专/大学，条件合格群体为完成高中 a7a >= 5)
gen trans3_col = .
replace trans3_col = 1 if a7a >= 9 & a7a != .
replace trans3_col = 0 if inlist(a7a, 5, 6, 7, 8)
label var trans3_col "升学转换3:完成大学(高中及以上样本)"

// -----------------------------------------------------------------------------
// 4.2 核心自变量：家庭社会经济地位与文化资本
// -----------------------------------------------------------------------------
// 14岁时父亲职业 ISEI (基于 isco08f，调用 iscogen 宏包)
/* 构造逻辑：
   剔除 -1 至 -5 等非有效编码；基于 Ganzeboom 国际标准职业分类转换算法，
   在 Stata 中调用 iscogen 宏包将四位数字的 ISCO-08 职业编码转换为国际社会经济地位指数（ISEI-08，取值约 10-89 分）；
   在实证回归与比较中除以 10 进入模型（fisei_10），以利于优势比（OR）和边际效应的直观解读。*/
iscogen fisei = isei(isco08f), from(isco08)
gen fisei_10 = fisei / 10
label var fisei "14岁父亲职业ISEI得分(原始值)"
label var fisei_10 "14岁父亲职业ISEI得分(/10)"

// 父母最高受教育年限 (paredu_max)
/* 构造逻辑：
   分别将父亲学历 (a89b) 与母亲学历 (a90b) 映射为标准教育年限 (0-19年)，
   随后取两者之最大值：paredu_max = max(fedu_years, medu_years)。*/
gen fedu_years = .
replace fedu_years = 0  if a89b == 1
replace fedu_years = 2  if a89b == 2
replace fedu_years = 6  if a89b == 3
replace fedu_years = 9  if a89b == 4
replace fedu_years = 12 if inlist(a89b, 5, 6, 7, 8)
replace fedu_years = 15 if inlist(a89b, 9, 10)
replace fedu_years = 16 if inlist(a89b, 11, 12)
replace fedu_years = 19 if a89b == 13
label var fedu_years "父亲受教育年限(年)"

gen medu_years = .
replace medu_years = 0  if a90b == 1
replace medu_years = 2  if a90b == 2
replace medu_years = 6  if a90b == 3
replace medu_years = 9  if a90b == 4
replace medu_years = 12 if inlist(a90b, 5, 6, 7, 8)
replace medu_years = 15 if inlist(a90b, 9, 10)
replace medu_years = 16 if inlist(a90b, 11, 12)
replace medu_years = 19 if a90b == 13
label var medu_years "母亲受教育年限(年)"

egen paredu_max = rowmax(fedu_years medu_years)
label var paredu_max "父母最高受教育年限(年)"

// -----------------------------------------------------------------------------
// 4.3 人口学与结构性控制变量
// -----------------------------------------------------------------------------
// 性别 (female: 0=男性, 1=女性)
gen female = (a2 == 2) if a2 != .
label var female "性别(1=女性, 0=男性)"

// 民族 (minority: 0=汉族, 1=少数民族)
gen minority = (a4 >= 2 & a4 <= 8) if a4 != .
label var minority "民族(1=少数民族, 0=汉族)"

// 出生历史队列 (cohort，划分为五大历史阶段代际)
gen cohort = .
replace cohort = 1 if a3a <= 1960 & a3a != .
replace cohort = 2 if a3a >= 1961 & a3a <= 1970
replace cohort = 3 if a3a >= 1971 & a3a <= 1980
replace cohort = 4 if a3a >= 1981 & a3a <= 1990
replace cohort = 5 if a3a >= 1991 & a3a != .
label define cohort_lab 1 "≤1960年" 2 "1961-1970" 3 "1971-1980" 4 "1981-1990" 5 "≥1991年"
label values cohort cohort_lab
label var cohort "出生历史队列"

// 户籍类型 (nonagri_hukou: 1=非农/居民户口, 0=农业户口)
gen nonagri_hukou = (inlist(a18, 2, 4)) if a18 != .
label var nonagri_hukou "户口性质(1=非农/居民, 0=农业)"

// 城乡社区属性 (urban_loc: 1=城镇社区, 0=农村村庄)
gen urban_loc = (isurban == 1) if isurban != .
label var urban_loc "现住地城乡类型(1=城镇, 0=农村)"

// -----------------------------------------------------------------------------
// 4.4 二次加工拓展变量（收入、本人ISEI、主观阶层认同、网顶）
// -----------------------------------------------------------------------------
// (1) 个人年总收入对数化与缩尾 (lninc, lninc_w)
/* 构造逻辑：
   以 a8a（去年全年个人总收入）为基准，剔除负数及 9999996-9999999 等特殊缺失代码；
   为纠正收入数据严重的右偏态并合理保留 919 例零收入样本，采用 ln(a8a + 1) 进行对数转换；
   利用 Stata 原生 _pctile 计算第 1 与第 99 百分位数（分别为 0 和 12.7367，对应原始收入 34 万元），
   实施 1%/99% 双侧缩尾（winsorization），有效平抑极端值干扰。*/
gen lninc = ln(a8a + 1)
label var lninc "个人年总收入对数ln(x+1)"

_pctile lninc if lninc != ., p(1 99)
gen lninc_w = lninc
replace lninc_w = r(r1) if lninc < r(r1) & lninc != .
replace lninc_w = r(r2) if lninc > r(r2) & lninc != .
label var lninc_w "个人年总收入对数(1%/99%缩尾)"

// (2) 被访者目前非农职业 ISEI (resp_isei, resp_isei_10)
/* 构造逻辑：
   针对入户面访样本中从事非农工作的群体，基于其 ISCO-08 职业编码 (isco08a59d)，
   调用 iscogen 宏包转换为国际社会经济地位指数（ISEI-08），未从事非农工作者自然缺失；
   同时除以 10 生成 resp_isei_10 用于模型估计。*/
iscogen resp_isei = isei(isco08a59d), from(isco08)
gen resp_isei_10 = resp_isei / 10
label var resp_isei "被访者目前非农职业ISEI"
label var resp_isei_10 "被访者目前非农职业ISEI(/10)"

// (3) 主观阶层认同 (class_current, class_age14)
/* 构造逻辑：
   基于 CGSS 1-10 级顶底阶梯量表（a43a 为当前自我地位，a43d 为 14 岁时家庭地位），
   剔除 -1 至 -3 等负值缺失编码，直接保留 1-10 得分（分值越高代表主观认同层级越高）。
   其中 14 岁家庭阶层 (class_age14) 亦作为代际流动模型中先赋地位的关键控制变量。*/
gen class_current = a43a
gen class_age14 = a43d
label var class_current "目前主观阶层认同(1-10分)"
label var class_age14 "14岁时家庭主观阶层(1-10分)"

// (4) 社会资本网络网顶与网络规模 (net_ceiling, net_size)
/* 构造逻辑：
   基于问卷模块 C 中经典的林南（Nan Lin）10 项职业位置发生器 (c9a-c9j，涵盖大学教师、律师、
   护士、程序员、中学教师、人事经理、农民、理发师、前台接待、警察)；
   将每类职业赋予其国际标准职业地位分（如律师=85，大学教师=76，中学教师=71，程序员=70，农民=10）；
   计算被访者社会关系网络中所有能够触达职业的分值最大值（Max Score），即为“网顶”（net_ceiling），
   用于测度个体或家庭关系网络中可动员社会资源的最高上限；无任何联系者编码为缺失。
   同时加总所认识的职业类型总数（0-10 类）构造网络规模 (net_size)。*/
gen net_size = (c9a == 1) + (c9b == 1) + (c9c == 1) + (c9d == 1) + (c9e == 1) + ///
               (c9f == 1) + (c9g == 1) + (c9h == 1) + (c9i == 1) + (c9j == 1)
label var net_size "社会网络规模(拥有联系职业类别数0-10)"

gen score_a = cond(c9a == 1, 76, .)
gen score_b = cond(c9b == 1, 85, .)
gen score_c = cond(c9c == 1, 42, .)
gen score_d = cond(c9d == 1, 70, .)
gen score_e = cond(c9e == 1, 71, .)
gen score_f = cond(c9f == 1, 68, .)
gen score_g = cond(c9g == 1, 10, .)
gen score_h = cond(c9h == 1, 32, .)
gen score_i = cond(c9i == 1, 37, .)
gen score_j = cond(c9j == 1, 53, .)

egen net_ceiling = rowmax(score_a score_b score_c score_d score_e score_f score_g score_h score_i score_j)
label var net_ceiling "社会网络网顶ISEI(最高声望得分10-85)"
drop score_*

// =============================================================================
// 第五部分：全量变量描述统计输出 (Descriptive Statistics Output)
// =============================================================================
di as text _newline "================================================================================"
di as text ">>> 第五部分：全量分析变量描述统计（含加权与未加权）"
di as text "================================================================================"

// 5.1 连续型变量加权描述统计 (采用入户设计权重 weight1)
di as text _newline "--------------------------------------------------------------------------------"
di as text "5.1 连续型变量加权描述统计表 [aweight=weight1]："
di as text "--------------------------------------------------------------------------------"
local cont_vars edu_years fisei fisei_10 paredu_max fedu_years medu_years lninc lninc_w resp_isei resp_isei_10 class_current class_age14 net_ceiling net_size
summarize `cont_vars' [aweight=weight1]

// 5.2 连续型变量无加权描述统计 (基准对照)
di as text _newline "--------------------------------------------------------------------------------"
di as text "5.2 连续型变量无加权描述统计表（原始样本基准对照）："
di as text "--------------------------------------------------------------------------------"
summarize `cont_vars'

// 5.3 分类型变量加权频数与百分比 (采用入户设计权重 weight1)
di as text _newline "--------------------------------------------------------------------------------"
di as text "5.3 分类型变量加权频数与占比分布 [aweight=weight1]："
di as text "--------------------------------------------------------------------------------"
local cat_vars trans1_jh trans2_sh trans3_col edu_ord female minority cohort nonagri_hukou urban_loc
foreach v of local cat_vars {
    di as text _newline ">>> 加权分布: `v' (" "`: var label `v''" ")"
    tabulate `v' [aweight=weight1]
}

// 5.4 分类型变量无加权频数与百分比
di as text _newline "--------------------------------------------------------------------------------"
di as text "5.4 分类型变量无加权频数与占比分布（原始频数对照）："
di as text "--------------------------------------------------------------------------------"
foreach v of local cat_vars {
    di as text _newline ">>> 原始频数: `v' (" "`: var label `v''" ")"
    tabulate `v'
}

// =============================================================================
// 第六部分：保存清洗后分析样本与关闭日志 (Save & Close Log)
// =============================================================================
di as text _newline ">>> 第六部分：保存分析样本"
save "CGSS2023_cleaned_tangjinhuan.dta", replace
di as text "分析数据集已成功保存为 CGSS2023_cleaned_tangjinhuan.dta"

di as text _newline "================================================================================"
di as text "作业一全部数据清洗、变量构造与描述统计执行完毕！"
di as text "================================================================================"

log close
exit, clear
